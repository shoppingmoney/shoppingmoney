								 <div role="tabpanel" class="tab-pane fade in active" id="highlights">
                                    <div class="row">
                                       <div class="col-xs-12">
                                          <div class="toch-reviews">
                                             <div class="toch-table">
											 <h5>PRODUCT FEATURES</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Brand:</strong></td>
                                                         <td><?=$specification['key_feature_brand'];?></td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Model ID:</strong></td>
                                                         <td><?=$specification['key_feature_model_id'];?></td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Part Number:</strong></td>
                                                         <td><?=$specification['key_feature_part_numberss'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											 </div>								
                                          </div>
                                       </div>
                                    </div>
                                 </div>