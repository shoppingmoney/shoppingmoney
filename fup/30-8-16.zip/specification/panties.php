								 <div role="tabpanel" class="tab-pane fade in active" id="highlights">
                                    <div class="row">
                                       <div class="col-xs-12">
                                          <div class="toch-reviews">
                                             <div class="toch-table">
											 <h5>PRODUCT FEATURES</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Lifestyle:</strong></td>
                                                         <td><?=$specification['key_feature_lifestyle'];?></td>
                                                      </tr>
													    <tr>
                                                         <td><strong>Model Name:</strong></td>
                                                         <td><?=$specification['key_feature_model_name'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
														</div>
										<div class="toch-table">
											 <h5>PRINTS & PATTERNS DETAILS</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Prints & Patterns:</strong></td>
                                                         <td><?=$specification['prints_patterns_details_prints_patterns'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>
										 <div class="toch-table">
											 <h5>PANTIES AND PATTERN TYPE</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Type:</strong></td>
                                                         <td><?=$specification['panties_and_pattern_type_type'];?></td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Style:</strong></td>
                                                         <td><?=$specification['panties_and_pattern_type_style'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>
                                           <div class="toch-table">
											     <h5>COLOR SET DETAILS</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Color Family:</strong></td>
                                                         <td><?=$specification['color_set_details_color_family_multi_selects'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
												</div>															
                                          </div>
                                       </div>
                                    </div>
                                 </div>