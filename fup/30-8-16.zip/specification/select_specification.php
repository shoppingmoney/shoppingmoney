<?php
switch($specification_tbl){
	
	case 'specification_29':
	include "specification/sarees.php";
	break;
	
	case 'specification_47':
	include "specification/Men_t_shirts.php";
	break;
	
	case 'specification_85':
	include "specification/mobile_phone.php";
	break;
	
	case 'specification_87':
	include "specification/skirts.php";
	break;
	
    case 'specification_89':
	include "specification/Women_Pant_Trouser.php";
	break;
	
	case 'specification_90':
	include "specification/Women_Capry.php";
	break;
	
	case 'specification_91':
	include "specification/printed_plazo.php";
	break;
	
	case 'specification_92':
	include "specification/maternity_wear.php";
	break;
	
	case 'specification_93':
	include "specification/sweat_shirts_hooded.php";
	break;
	
	case 'specification_94':
	include "specification/tops_tees_tunics.php";
	break;
	
	case 'specification_95':
	include "specification/shrugs_jackets.php";
	break;
	
	case 'specification_96':
	include "specification/activewear.php";
	break;
	
	case 'specification_117':
	include "specification/airfryers_deepfryers.php";
	break;
	
	case 'specification_120':
	include "specification/electric_cookers.php";
	break;
	
	case 'specification_116':
	include "specification/food_processor.php";
	break;
	
	case 'specification_115':
	include "specification/juicer_mixer.php";
	break;
	
	case 'specification_121':
	include "specification/roti_makers.php";
	break;
	
	case 'specification_162':
	include "specification/dupatta_shawls.php";
	break;
	
	case 'specification_163':
	include "specification/blouses.php";
	break;
	
	case 'specification_166':
	include "specification/kurta_kurti.php";
	break;
	
	case 'specification_171':
	include "specification/fusion_wear.php";
	break;
	
	case 'specification_177':
	include "specification/bra.php";
	break;
	
	case 'specification_178':
	include "specification/camisoles.php";
	break;
	
	case 'specification_179':
	include "specification/Lingerie_sets.php";
	break;
	
	case 'specification_180':
	include "specification/panties.php";
	break;
	
	case 'specification_181':
	include "specification/shapwear.php";
	break;
	
	case 'specification_182':
	include "specification/sleep_loungewear.php";
	break;
	
	case 'specification_186':
	include "specification/adapters.php";
	break;
	
	case 'specification_187':
	include "specification/headphone.php";
	break;
	
	case 'specification_188':
	include "specification/ups.php";
	break;
	
	
}
?>