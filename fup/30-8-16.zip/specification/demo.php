								 <div role="tabpanel" class="tab-pane fade in active" id="highlights">
                                    <div class="row">
                                       <div class="col-xs-12">
                                          <div class="toch-reviews">
                                             <div class="toch-table">
											 <h5>PRODUCT FEATURES</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
                                                      <tr>
                                                         <td><strong>Brand:</strong></td>
                                                         <td><?=$specification['brand_brand'];?></td>
                                                      </tr>
													   
                                                        </tbody>
														</table>

											</div>
											   <div class="toch-table">
											 <h5>DISPLAY MOBILE</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
                                                      <tr>
                                                         <td><strong>Display Size (Cms):</strong></td>
                                                         <td><?=$specification['display_mobile_display_size_cms_'];?> Cm</td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Resolution Type:</strong></td>
                                                         <td><?=$specification['display_mobile_resolution_type'];?> Pixels</td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Display Type:</strong></td>
                                                         <td><?=$specification['display_mobile_display_type'];?></td>
                                                      </tr>
													    <tr>
                                                         <td><strong>Display Size (Inches):</strong></td>
                                                         <td><?=$specification['display_mobile_display_size_inches_'];?> Inch</td>
                                                      </tr>
													  
                                                        </tbody>
														</table>
                                             </div>
											 
											  <div class="toch-table">
											 <h5>GENERAL FEATURES</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
                                                      <tr>
                                                         <td><strong>Talk Time:</strong></td>
                                                         <td><?=$specification['battery_talktime'];?> Hours</td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Form:</strong></td>
                                                         <td><?=$specification['general_features_form'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
                                             </div
                                          </div>
                                       </div>
                                    </div>
                                 </div>