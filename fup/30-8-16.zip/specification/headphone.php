								 <div role="tabpanel" class="tab-pane fade in active" id="highlights">
                                    <div class="row">
                                       <div class="col-xs-12">
                                          <div class="toch-reviews">
                                             <div class="toch-table">
											 <h5>PRODUCT FEATURES</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Brand:</strong></td>
                                                         <td><?=$specification['brand_brand'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
														</div>
										<div class="toch-table">
											 <h5>MODEL</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Model Number:</strong></td>
                                                         <td><?=$specification['model_model_number'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>
										 <div class="toch-table">
											 <h5>MIXERS & PROCESSORS SPECIFICATION</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>No. of Speed Settings:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_no_of_speed_settings'];?></td>
                                                      </tr>lable
													  <tr>
                                                         <td><strong>Type:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_type'];?></td>
                                                      </tr>
													   <tr>
                                                         <td><strong>No. of Jars:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_no_of_jars'];?></td>
                                                      </tr>
													  <tr>
                                                         <td><strong>Material of Jar:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_material_of_jar'];?></td>
                                                      </tr>
													  <tr>
                                                         <td><strong>Automatic Shut-off:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_automatic_shut_off'];?></td>
                                                      </tr>
													  <tr>
                                                         <td><strong>Anti Slip Rubber Feet:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_anti_slip_rubber_feet'];?></td>
                                                      </tr>
													  <tr>
                                                         <td><strong>Voltage:</strong></td>
                                                         <td><?=$specification['mixers_processors_specification_voltage'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>
                                            <div class="toch-table">
											 <h5>WHAT IS IN THE BOX (?)</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Items in the Box:</strong></td>
                                                         <td><?=$specification['what_is_in_the_box_items_in_the_box_multi_select'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>
                                             <div class="toch-table">
											 <h5>WARRANTY DETAILS</h5>
                                                <table class="table table-striped table-bordered">
                                                   <tbody>
												    <tr>
                                                         <td><strong>Warranty Available:</strong></td>
                                                         <td><?=$specification['warranty_details_warranty_available'];?></td>
                                                      </tr>
													   <tr>
                                                         <td><strong>Duration:</strong></td>
                                                         <td><?=$specification['warranty_details_durations'];?></td>
                                                      </tr>
                                                        </tbody>
														</table>
											</div>											
                                          </div>
                                       </div>
                                    </div>
                                 </div>