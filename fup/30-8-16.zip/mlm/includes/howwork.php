 
<!-- <article>
         <div class='parallax'>
            <div class='foo_a'>Aaa</div>
            <div class='foo_b'>Bbb</div>
            <div class='foo_c'>Ccc</div>
        
         </div>
      </article>-->

<img src="../img/4.jpg">
	