<?php

define("BASE","http://localhost/mlm");

?>

